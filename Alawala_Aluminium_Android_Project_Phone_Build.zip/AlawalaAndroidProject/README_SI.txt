Alawala Aluminium Android App - Source Project

මෙය Android Studio project source එකකි; සෘජුව install කළ හැකි APK ගොනුවක් නොවේ.

APK එක build කිරීමට:
1. Android Studio ස්ථාපනය කර project folder එක open කරන්න.
2. Gradle sync අවසන් වන තුරු සිටින්න.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) තෝරන්න.
4. APK එක app/build/outputs/apk/debug/app-debug.apk තුළ ලැබේ.

විශේෂාංග:
- Offline WebView app
- Local browser storage / backup-restore
- Phone Contacts picker: පාරිභෝගිකයා තෝරා නම සහ දුරකථනය පුරවයි
- Logo, English UI, registration no. W/ATH/9663

සටහන: APK build කිරීමට Android SDK/Android Studio අවශ්‍ය වේ. මෙම environment එකේ Android SDK සහ Gradle build tools නොමැති බැවින් මෙහිදී APK එක compile කර නැත.
